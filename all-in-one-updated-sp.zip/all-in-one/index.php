<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All in one Bundle</title>
    <script type='text/javascript' src='https://www.educba.com/academy/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'></script>
</head>
<body>
    <div class="site-inner">
        <?php include('allinonebundleexcel.php');?>
    </div>    
    
</body>
</html>