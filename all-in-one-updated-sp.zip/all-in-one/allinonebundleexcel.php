<style>
@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;900&display=swap');
@import url('https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css');
@import url('https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css');
@import url('https://unpkg.com/aos@2.3.1/dist/aos.css');
@import url('https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css');

:root {
    --first-color: #0675f6;
    --highlight-color: #D4FF2A;
    --dark-color: rgba(54, 9, 64, 1);
    --bs-body-color-rgb: 33, 37, 41
}
*{
    font-size: 16px;
}
a {
    text-decoration: none;
    color: #3b3b3b;
}

a:hover {
    color: #3b3b3b;
}

.site-gradient {
    background: linear-gradient(135deg, #0693E3 0%, #9b51e0 100%) !important;
}


.page-template-page-builder .site-header {
    /*background: linear-gradient(135deg, #0693E3 0%, #9b51e0 100%) !important;*/
}


.site-gradient-2 {
    background: rgb(54, 9, 64);
    background: linear-gradient(90deg, rgba(54, 9, 64, 1) 0%, rgba(54, 9, 64, 1) 35%, rgba(240, 95, 87, 1) 100%);
}

.roboto {
    font-family: 'Roboto', sans-serif;
}

.site-inner h1,
.site-inner h2,
.site-inner h3,
.site-inner h4,
.site-inner h5,
.site-inner h6 {
    font-family: 'Roboto', sans-serif;
}

.text-first {
    color: var(--dark-color);
}


.fs-large-xxx {
    font-size: 45px;
}

.fs-large-xx {
    font-size: 40px;
}

.fs-large-x {
    font-size: 35px;
}

.fs-large {
    font-size: 30px;
}

.fs-medium {
    font-size: 18px;
}

.fs-small {
    font-size: 12px;
}

.rounded {
    border-radius: 0.375 !important;
}

.rounded-1 {
    border-radius: 0.25rem !important;
}

.rounded-2 {
    border-radius: 0.375rem !important;
}

.rounded-3 {
    border-radius: 0.5rem !important;
}

.rounded-4 {
    border-radius: 1rem !important;
}

.rounded-5 {
    border-radius: 2rem !important;
}


.text-darker {
    color: var(--dark-color);
}


.gradient-text {
    background: linear-gradient(90deg, rgba(54, 9, 64, 1) 0%, rgba(54, 9, 64, 1) 35%, rgba(240, 95, 87, 1) 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    padding: 10px 0px;
}

.w-15 {
    width: 15% !important;
}

.bg-Online_Classes {
    width: 50px;
    height: 50px;
    background: url(https://cdn.educba.com/images/what_you_get_sprite-icons-aio.png) 0 0
}

.bg-Technical_Support {
    width: 50px;
    height: 50px;
    background: url(https://cdn.educba.com/images/what_you_get_sprite-icons-aio.png) -50px 0
}

.bg-Mobile_App_Access {
    width: 50px;
    height: 50px;
    background: url(https://cdn.educba.com/images/what_you_get_sprite-icons-aio.png) -100px 0
}

.bg-Case_Studies {
    width: 50px;
    height: 50px;
    background: url(https://cdn.educba.com/images/what_you_get_sprite-icons-aio.png) -150px 0
}

.bg-Downloads {
    width: 50px;
    height: 50px;
    background: url(https://cdn.educba.com/images/what_you_get_sprite-icons-aio.png) -200px 0
}

.bg-Skill-Based {
    width: 50px;
    height: 50px;
    background: url(https://cdn.educba.com/images/what_you_get_sprite-icons-aio.png) -250px 0
}

.bg-Free-Access {
    width: 50px;
    height: 50px;
    background: url(https://cdn.educba.com/images/what_you_get_sprite-icons-aio.png) -300px 0
}

.styled-table {
    border-collapse: collapse;
    border-radius: 10px 10px 0px 0px;
    border: 1px solid transparent;
    margin: 25px 0;
    font-size: 0.9em;
    font-family: sans-serif;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
}

.styled-table thead tr {
    background-color: var(--dark-color);
    border-collapse: collapse;
    color: #ffffff;
    text-align: left;
}

.styled-table th:first-of-type {
    border-top-left-radius: 10px;
}

.styled-table th:last-of-type {
    border-top-right-radius: 10px;
}

.styled-table th,
.styled-table td {
    padding: 12px 15px;
}

.styled-table tbody tr {
    /*border-bottom: 1px solid #dddddd;*/
}

.styled-table tbody tr:nth-of-type(even) {
    /*background-color: #f3f3f3;*/
}

.styled-table tbody tr:last-of-type {
    /*border-bottom: 2px solid #009879;*/
}

.styled-table tbody tr.active-row {
    font-weight: bold;
    color: #009879;
}

.style-table tr {
    border: 1px solid #000;
}

.cname {
    text-decoration: underline;
    font-weight: bold;
}

.inner-shadow {
    box-shadow: inset 0 1rem 3rem rgba(var(--bs-body-color-rgb), .175) !important
}

.image-container {
    position: relative;
}

.image-container .time {
    position: absolute;
    background: #7e7e7e;
    padding: 2px;
    border-radius: 5px;
    font-size: 10px;
}

.image-container .play-button {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    z-index: 3;
}

.animated-btn {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    line-height: 30px;
    display: inline-block;
    text-align: center;
    background: #ff3f3f;
    position: relative;
}

.play-icon {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    z-index: 3;
}

.animated-btn::before,
.animated-btn::after {
    content: '';
    display: block;
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    border-radius: 50%;
    background: rgba(255, 63, 63, 0.8);
    animation: ripple-1 2s infinite ease-in-out;
    z-index: -1;
}

.animated-btn::after {
    background: rgba(255, 63, 63, 0.6);
    animation: ripple-2 2s infinite ease-in-out;
    animation-delay: 0.5s;
}

@keyframes ripple-1 {
    0% {
        transform: scale(1);
        opacity: 1;
    }

    100% {
        transform: scale(1.5);
        opacity: 0;
    }
}

@keyframes ripple-2 {
    0% {
        transform: scale(1);
        opacity: 1;
    }

    100% {
        transform: scale(1.7);
        opacity: 0;
    }
}

.animate-charcter {
    text-transform: uppercase;
    background-image: linear-gradient(-225deg,
            #231557 0%,
            #44107a 25%,
            #ff1361 50%,
            #44107a 75%,
            #231557 100%);
    background-size: auto auto;
    background-clip: border-box;
    background-size: 200% auto;
    color: #fff;
    background-clip: text;
    text-fill-color: transparent;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: textclip 2s linear infinite;
    display: inline-block;

}

@keyframes textclip {
    to {
        background-position: 200% center;
    }
}

.golden-gradient {
    background: rgb(146, 99, 22);
    background: linear-gradient(127deg, rgba(146, 99, 22, 1) 0%, rgba(243, 214, 139, 1) 44%, rgba(149, 101, 23, 1) 100%);
    transition: all 0.3s ease-in-out;
}

.golden-gradient:hover {
    background: rgb(146, 99, 22);
    background: linear-gradient(130deg, rgba(146, 99, 22, 1) 0%, rgba(243, 214, 139, 1) 44%, rgba(149, 101, 23, 1) 100%);
    transition: all 0.3s ease-in-out;
}

/******************* Timeline *****************/
.main-timeline4 {
    overflow: hidden;
    position: relative
}

.main-timeline4:before {
    content: "";
    width: 5px;
    height: 97%;
    background: #333;
    position: absolute;
    top: 70px;
    left: 50%;
    transform: translateX(-50%)
}

.main-timeline4 .timeline-content:before,
.main-timeline4 .timeline:before {
    top: 50%;
    transform: translateY(-50%);
    content: ""
}

.main-timeline4 .timeline {
    width: 50%;
    padding-left: 100px;
    float: right;
    position: relative
}

.main-timeline4 .timeline:before {
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: #fff;
    border: 5px solid #333;
    position: absolute;
    left: -10px
}

.main-timeline4 .timeline-content {
    display: block;
    /* padding-left: 150px; */
    position: relative;
    box-shadow: inset 0 0 10px rgba(0, 0, 0, .4);
    padding: 2rem;

}

.main-timeline4 .timeline-content:before {
    width: 90px;
    height: 10px;
    border-top: 7px dotted #333;
    position: absolute;
    left: -92px
}

.main-timeline4 .year {
    display: inline-block;
    width: 120px;
    height: 120px;
    line-height: 100px;
    border-radius: 50%;
    border: 10px solid #f54957;
    font-size: 30px;
    color: #f54957;
    text-align: center;
    box-shadow: inset 0 0 10px rgba(0, 0, 0, .4);
    position: relative;
    top: 0;
    left: 0
}


.main-timeline4 .inner-content {
    padding: 20px 0 0 0;
}

.main-timeline4 .title {
    font-size: 24px;
    font-weight: 600;
    color: #f54957;
    text-transform: uppercase;
    margin: 0 0 10px
}

.main-timeline4 .description {
    font-size: 14px;
    color: #6f6f6f;
    margin: 0 0 15px
}

.main-timeline4 .timeline:nth-child(2n) {
    padding: 0 100px 0 0
}

.main-timeline4 .timeline:nth-child(2n) .timeline-content:before,
.main-timeline4 .timeline:nth-child(2n) .year,
.main-timeline4 .timeline:nth-child(2n):before {
    left: auto;
    right: -10px
}

/* .main-timeline4 .timeline:nth-child(2n) .timeline-content {
            padding: 0 150px 0 0
        } */

.main-timeline4 .timeline:nth-child(2n) .timeline-content:before {
    right: -92px
}

.main-timeline4 .timeline:nth-child(2n) .year {
    right: 0
}

.main-timeline4 .timeline:nth-child(2n) .year:before {
    right: auto;
    left: 0;
    border-left: none;
    border-right: 20px solid #f54957;
    transform: rotate(-45deg)
}

.main-timeline4 .timeline:nth-child(2) {
    margin-top: 110px
}

.main-timeline4 .timeline:nth-child(odd) {
    margin: -110px 0 0;
    text-align: left;
}

.main-timeline4 .timeline:nth-child(even) {
    margin-bottom: 80px;
    text-align: left;

}

.main-timeline4 .timeline:first-child,
.main-timeline4 .timeline:last-child:nth-child(even) {
    margin: 0
}

.main-timeline4 .timeline:nth-child(2n) .year {
    border-color: #1ebad0;
    color: #1ebad0
}


.main-timeline4 .timeline:nth-child(2n) .title {
    color: #1ebad0
}

.main-timeline4 .timeline:nth-child(3n) .year {
    border-color: #7cba01;
    color: #7cba01
}


.main-timeline4 .timeline:nth-child(3n) .title {
    color: #7cba01
}

.main-timeline4 .timeline:nth-child(4n) .year {
    border-color: #f8781f;
    color: #f8781f
}

.main-timeline4 .timeline:nth-child(4) .year:before {
    border-right-color: #f8781f
}

.main-timeline4 .timeline:nth-child(4n) .title {
    color: #f8781f
}

@media only screen and (max-width:1200px) {
    .main-timeline4 .year {
        top: 50%;
        transform: translateY(-50%)
    }
}

@media only screen and (max-width:990px) {
    .main-timeline4 .timeline {
        padding-left: 75px
    }

    .main-timeline4 .timeline:nth-child(2n) {
        padding: 0 75px 0 0
    }

    .main-timeline4 .timeline-content {
        padding-left: 130px
    }

    .main-timeline4 .timeline:nth-child(2n) .timeline-content {
        padding: 0 130px 0 0
    }

    .main-timeline4 .timeline-content:before {
        width: 68px;
        left: -68px
    }

    .main-timeline4 .timeline:nth-child(2n) .timeline-content:before {
        right: -68px
    }
}

@media only screen and (max-width:767px) {
    .main-timeline4 {
        overflow: visible
    }

    .main-timeline4:before {
        height: 100%;
        top: 0;
        left: 0;
        transform: translateX(0)
    }

    .main-timeline4 .timeline:before,
    .main-timeline4 .timeline:nth-child(2n):before {
        top: 60px;
        left: -9px;
        transform: translateX(0)
    }

    .main-timeline4 .timeline,
    .main-timeline4 .timeline:nth-child(even),
    .main-timeline4 .timeline:nth-child(odd) {
        width: 100%;
        float: none;
        text-align: center;
        padding: 2.5rem 0;

    }

    .main-timeline4 .timeline-content,
    .main-timeline4 .timeline:nth-child(2n) .timeline-content {
        padding: 2rem;
    }

    .main-timeline4 .timeline-content:before,
    .main-timeline4 .timeline:nth-child(2n) .timeline-content:before {
        display: none
    }

    .main-timeline4 .timeline:nth-child(2n) .year,
    .main-timeline4 .year {
        position: relative;
        transform: translateY(0)
    }

    .main-timeline4 .timeline:nth-child(2n) .year:before,
    .main-timeline4 .year:before {
        border: none;
        border-right: 20px solid #f54957;
        border-top: 10px solid transparent;
        border-bottom: 10px solid transparent;
        top: 50%;
        left: -23px;
        bottom: auto;
        right: auto;
        transform: rotate(0)
    }


    .main-timeline4 .inner-content {
        padding: 10px
    }
}

.icon {
    max-height: 30px;
    width: auto;
}

.course-image-container {
    overflow: hidden;
    max-height: 325px;
}

.course-image-container img {
    width: 400px;
    height: 700px;
    object-fit: cover;
}

.timer-component {
    padding: 10px 5px;
    margin: 0px 5px;
    border: 2px solid #fff;
    border-radius: 50%;
    width: 55px;
    height: 55px;
    font-weight: 600;
    background: rgb(146, 99, 22);
    background: linear-gradient(127deg, rgba(146, 99, 22, 1) 0%, rgba(243, 214, 139, 1) 44%, rgba(149, 101, 23, 1) 100%);
    color: #2e2e2e;
    font-weight: 800;
    font-size: 20px;
    font-family: 'Roboto', sans-serif;
}

/*testimonial*/
.testimonial {
    position: relative;
    display:none;    
}

.testimonial-new {
    background: #360940;
    background-image: url(https://raw.githubusercontent.com/RahulSahOfficial/testimonials_grid_section/5532c958b7d3c9b910a216b198fdd21c73112d84/images/bg-pattern-quotation.svg);
    background-repeat: no-repeat;
    background-position-x: 90%;
}

.testimonial-icon {
    position: absolute;
    right: 0%;
    top: -10%;
    font-size: 50px;
    background: linear-gradient(90deg, rgba(54, 9, 64, 1) 0%, rgba(54, 9, 64, 1) 45%, rgba(240, 95, 87, 1) 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
#topdiv {
    position:fixed;
    bottom:0px;

}
.strip-container {position:relative;}
.strip-container img{
    position: absolute;
    top: -150%;
    right: 0px;
}
</style>
<section id="blank-header" class="py-5 site-gradient-2">
    <div class="py-3"></div>
</section>

<section id="bannersection" class="py-5 site-gradient-2">
    <div class="container text-white mt-5">
        <div class="row mt-5">
            <div class="col-md-7 mb-5">
                <p>All-in-one Bundle</p>
                <h2 class="fs-large-xxx fw-bold mb-3">Microsoft Excel VBA Macros</h2>
                <p class="fs-medium mt-3 mb-3 pe-5">Lifetime Unlimited Access to 120+ world-class MS Excel, VBA & Macros courses, hands-on projects, job-ready certificate programs and learning paths, tests and quizzes, unlimited certificates, future and upcoming courses — all included.</p>

                <div class="d-flex justify-content-start">
                    <div class="d-flex justify-content-bottom bg-white rounded-3 shadow align-items-center px-4">
                        <div id="strikeprice" class="ms-2 fs-medium text-dark"><del>₹ 24900 </del></div>
                        <div id="payprice" class="ms-2 fs-large-xx fw-bold animate-charcter d-inline">₹ 12449</div>
                    </div>
                </div>
                <div class="timer-container">
                    <p class="ps-2 mt-3">offer ends in:</p>
                    <!-- <div id="timer"></div>-->
                    <div class="d-flex justify-content-start text-center">
                        <div class="d-flex-column">
                            <div id="days" class="timer-component">00</div>
                            <p>days</p>
                        </div>
                        <div class="d-flex-column">
                            <div id="hour" class="timer-component">00</div>
                            <p>hours</p>
                        </div>
                        <div class="d-flex-column">
                            <div id="minute" class="timer-component">00</div>
                            <p>minutes</p>
                        </div>
                        <div class="d-flex-column">
                            <div id="second" class="timer-component">00</div>
                            <p>sec</p>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-start mt-3">
                    <a href="https://www.educba.com/all-in-one"
                        class="px-3 py-2 rounded-2 fs-large fw-bold btn-warning text-dark">Take this Bundle</a>
                </div>
            </div>
            <div class="col-md-5 mb-5 d-flex align-items-center">
                <img src="https://www.educba.com/academy/1677240038004/wp-content/uploads/2023/04/excel-hero.png"
                    class="w-100 rounded-5" alt="">
            </div>

        </div>
    </div>
</section>

<section id="advantages" class="py-5 bg-light inner-shadow">
    <div class="container text-center">
        <div class="row">
            <div class="col-md-12 mb-3">
                <h3 class="gradient-text fw-bold fs-large-xx mb-3">EDUCBA Advantages</h3>
				<p class="mb-5">All-in-one Excel VBA Macros Course Bundle is a comprehensive package that includes all prominent and essential MS Excel courses in one place in diverse fields of – MS Excel, Pivot Table, Graphs & Charts, Functions, Dashboards, VBA and Macros, and much more. This course will provide the practical knowledge and skills needed to perform Excel based analysis in the real world. </p>
            </div>
            <div class="col-md-3 p-2 mb-3">
                <img src="https://www.educba.com/academy/wp-content/uploads/2023/03/learn-anything.png"
                    class="mx-auto w-25 mb-3" alt="">
                <h4 class="gradient-text fs-medium mb-3">Learn anything</h4>
                <p>Choose any topic, and advance your skills</p>
            </div>
            <div class="col-md-3 p-2 mb-3">
                <img src="https://www.educba.com/academy/wp-content/uploads/2023/03/save-money.png"
                    class="mx-auto w-25 mb-3" alt="">
                <h4 class="gradient-text fs-medium mb-3">Save money</h4>
                <p>Take multiple courses from diverse fields at no additional cost</p>
            </div>
            <div class="col-md-3 p-2 mb-3">
                <img src="https://www.educba.com/academy/wp-content/uploads/2023/03/flexible-learning.png"
                    class="mx-auto w-25 mb-3" alt="">
                <h4 class="gradient-text fs-medium mb-3">Flexible learning</h4>
                <p>Learn at your own pace, move between multiple courses, or switch to a different course</p>
            </div>
            <div class="col-md-3 p-2 mb-3">
                <img src="https://www.educba.com/academy/wp-content/uploads/2023/03/certificate.png"
                    class="mx-auto w-25 pt-1 mb-3" alt="">
                <h4 class="gradient-text fs-medium mb-3">Unlimited certificates</h4>
                <p>Earn a certificate for every learning program that you complete at no additional cost</p>
            </div>

        </div>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h3 class="fs-large-xx fw-bold text-center gradient-text mb-5">What you’ll get</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 d-flex align-items-center">
                <img src="https://cdn.educba.com/images/all-in-one_system.png" class="w-100" alt="">
            </div>
            <div class="col-md-6 px-5 ">

                <div class="d-flex align-items-center">
                    <i class="bi bi-check2-circle fs-large gradient-text"></i>
                    <p class="fs-medium ms-3 mb-0 py-0"> 	Lifetime Unlimited Access to 120+ world-class MS Excel courses, hands-on projects, job-ready certificate programs and learning paths, tests and quizzes </p>
                </div>
                <div class="d-flex align-items-center">
                    <i class="bi bi-clock fs-large gradient-text"></i>
                    <p class="fs-medium ms-3 mb-0 py-0"> 	All current and future access to courses and learning paths</p>
                </div>
                <div class="d-flex align-items-center">
                    <i class="bi bi-award fs-large gradient-text"></i>
                    <p class="fs-medium ms-3 mb-0 py-0"> 500+ hours of upskilling content</p>
                </div>
                <div class="d-flex align-items-center">
                    <i class="bi bi-infinity fs-large gradient-text"></i>
                    <p class="fs-medium ms-3 mb-0 py-0">	Unlimited certificates</p>
                </div>
                <div class="d-flex align-items-center">
                    <i class="bi bi-file-earmark-spreadsheet fs-large gradient-text"></i>
                    <p class="fs-medium ms-3 mb-0 py-0">200+ downloadable excel templates</p>
                </div>
                <div class="d-flex align-items-center">
                    <i class="bi bi-graph-up-arrow fs-large gradient-text"></i>
                    <p class="fs-medium ms-3 mb-0 py-0"> 	Latest trends in real world covered</p>
                </div>
                <div class="d-flex align-items-center">
                    <i class="bi bi-file-earmark-plus fs-large gradient-text"></i>
                    <p class="fs-medium ms-3 mb-0 py-0"> New content added every month</p>
                </div>
                <div class="d-flex align-items-center">
                    <i class="bi bi-percent fs-large gradient-text"></i>
                    <p class="fs-medium ms-3 mb-0 py-0"> 100% online & self-paced
                        curation</p>
                </div>
                <div class="d-flex align-items-center">
                    <i class="bi bi-clock fs-large gradient-text"></i>
                    <p class="fs-medium ms-3 mb-0 py-0"> Lifetime of support at your
                        convenience</p>
                </div>
                <div class="d-flex align-items-center">
                    <i class="bi bi-clock fs-large gradient-text"></i>
                    <p class="fs-medium ms-3 mb-0 py-0"> Lifetime access to the
                        complete resource bundle</p>
                </div>
                <div class="d-flex align-items-center">
                    <i class="bi bi-cash-stack fs-large gradient-text"></i>
                    <p class="fs-medium ms-3 mb-0 py-0"> Convenient and cost-effective
                        way to gain knowledge in multiple domains</p>
                </div>
            </div>
        </div>
        <div class="row text-center mt-5">
            <div class="col-12">
                <a href="" class="btn fs-large fw-bold site-gradient-2 text-white">Take
                    this Bundle</a>
            </div>
        </div>
    </div>
</section>


<section id="whatyoulearn" class="py-5 site-gradient-2 inner-shadow text-white">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-12 mb-3">
                <h3 class="fs-large-xx mb-3 fw-bold">What Will You Learn?</h3>
                <p class="">This bundle helps you master</p>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                        <i class="bi bi-bank fs-large gradient-text"></i>
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">Excel Formulas & Functions </h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                        <i class="bi bi-cash-coin fs-large gradient-text"></i>
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">Excel Dashboard</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                        <i class="bi bi-cash-stack fs-large gradient-text"></i>
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">VBA & Macros</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                        <i class="bi bi-cpu fs-large gradient-text"></i>
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">Excel for Data Analyst</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                        <i class="bi bi-cash-coin fs-large gradient-text"></i>
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">Excel for Financial Analyst</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                        <i class="bi bi-person-plus-fill fs-large gradient-text"></i>
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">Excel for HR</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                        <i class="bi bi-file-earmark-spreadsheet fs-large gradient-text"></i>
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">Excel for Marketing</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                        <i class="bi bi-building-gear fs-large gradient-text"></i>
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">Microsoft Office</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                        <i class="bi bi-brush fs-large gradient-text"></i>
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">Pivot Table</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                        <i class="bi bi-person-check fs-large gradient-text"></i>
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">Spreadsheet Creation</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                        <i class="bi bi bi-person-bounding-box fs-large gradient-text"></i>
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">MS Word, PPT, MS Access</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="p-2">
                    <h4 class="fs-medium fw-bold w-100">And many more skills.</h4>
                </div>
            </div>
        </div>
        


    </div>
</section>

<section id="curriculum" class="py-5 bg-light inner-shadow">
    <div class="container">
        <div class="row">
            <div class="col-12 mb-3">
                <h3 class="gradient-text fs-large-xx fw-bold">Curriculum</h3>
            </div>
            <div class="col-12 mb-3">
                <!-- Main Accordian-->
                <div class="accordion accordion-flush" id="curriculum">
                    <div class="accordion-item bg-white shadow mb-3">
                        <!-- Item Start -->
                        <h2 class="accordion-header" id="financialanalyst-heading">
                            <button class="accordion-button collapsed fs-medium fw-bold" type="button"
                                data-bs-toggle="collapse" data-bs-target="#financialanalyst" aria-expanded="false"
                                aria-controls="flush-collapseOne">
                                Excel Training (23 Courses, 9+ Projects)
                            </button>
                        </h2>
                        <div id="financialanalyst" class="accordion-collapse collapse"
                            aria-labelledby="financialanalyst-heading" data-bs-parent="#curriculum">
                            <div class="accordion-body">
                                <div class="curriculum-inner-section">
                                    <p class="mb-3"><strong class="fs-medium">Goal:</strong> This course aims to walk you through lifesaving Excel tricks that will allow you to implement them in real life, saving you time and effort.</p>
                                    <p class="mb-3"><strong class="fs-medium">Learning Objective:</strong> After completing this module, you should be able to:</p>
                                    <div class="row">
            <div class="col-12 mb-3">
                <ul>
                    <li>Comprehend basic and advanced Excel concepts</li>
                    <li>Summarize extensive data using Pivot Tables</li>
                    <li>Create Excel reports</li>
                    <li>Understand VBA & Macros using case studies.
                    </li>
                    <li>Build predictive models and applications with AI and machine learning.</li>
                    
                </ul>
            </div>
                                    </div>
                                    <div class="row">
            <div class="col-12 mb-3">
            <p class="mb-3"><strong class="fs-medium">Core Topics:</strong>
                <ul>
                    <li>Basic Excel</li>
                    <li>Advanced Excel</li>
                    <li>Advanced Excel Formulas</li>
                    <li>Shortcuts in Microsoft Excel
                    </li>
                    <li>Analysis with Pivot Tables</li>
                    <li>Graphs & Charts in Microsoft Excel</li>
                    <li>Financial Functions In Excel</li>
                    <li>Statistical Tools in Microsoft Excel</li>
                    <li>Comprehensive VBA and Macros.</li>
                    
                </ul>
            </div>

        </div>
                                </div>
                                </div> 
                        </div>
                    </div><!-- Item Ends -->

                    <div class="accordion-item bg-white shadow mb-3">
                        <!-- Item Start -->
                        <h2 class="accordion-header" id="datascience-heading">
                            <button class="accordion-button collapsed fs-medium fw-bold" type="button"
                                data-bs-toggle="collapse" data-bs-target="#datascience" aria-expanded="false"
                                aria-controls="datascience">
                                Excel Advanced Training (16 Courses, 23+ Projects)
                            </button>
                        </h2>
                        <div id="datascience" class="accordion-collapse collapse" aria-labelledby="datascience-heading"
                            data-bs-parent="#curriculum">
                            <div class="accordion-body">
                                <div class="curriculum-inner-section">
                                <p class="mb-3"><strong class="fs-medium">Goal:</strong> This course aims to prepare you to solve real-world business challenges using Excel's data analysis tools.</p>
                                <p class="mb-3"><strong class="fs-medium">Learning Objective:</strong> After completing this module, you should be able to:</p>
                                <div class="row">
            <div class="col-12 mb-3">
                <ul>
                    <li>Understand Gantt charts and data series in Excel</li>
                    <li>Under Power Excel</li>
                    <li>Understand how business intelligence can be achieved through Excel</li>
                    <li>Understand statistical tools like central tendency, dispersion, correlation, and regression etc.</li>                    
                </ul>
            </div>
                </div>
           <div class="row">
            <div class="col-12 mb-3">
            <p class="mb-3"><strong class="fs-medium">Core Topics:</strong>
                <ul>
                    <li>Basic Excel Training</li>
                    <li>Advanced Excel Training</li>
                    <li>Data Analysis Using Excel</li>
                    <li>Gantt Chart Tutorials</li>
                    <li>Power Excel </li>
                    <li>Microsoft Excel Reports</li>
                    <li>Business Intelligence using Microsoft Excel</li>
                    <li>Microsoft Excel for Data Analyst</li>
                    <li>Statistical Tools in Microsoft Excel</li>
                    
                </ul>
            </div>

        </div>
                                   
                                </div>
                            </div>
                        </div>
                    </div><!-- Item Ends -->

                    <div class="accordion-item bg-white shadow mb-3">
                        <!-- Item Start -->
                        <h2 class="accordion-header" id="software-heading">
                            <button class="accordion-button collapsed fs-medium fw-bold" type="button"
                                data-bs-toggle="collapse" data-bs-target="#software" aria-expanded="false"
                                aria-controls="software">
                                Excel for Finance Training (18 Courses, 7+ Projects)
                            </button>
                        </h2>
                        <div id="software" class="accordion-collapse collapse" aria-labelledby="software-heading"
                            data-bs-parent="#curriculum">
                            <div class="accordion-body">
                                <div class="curriculum-inner-section">
                                <p class="mb-3"><strong class="fs-medium">Goal:</strong> This course provides a better understanding of Microsoft Excel for Financial Analysts. The program will cover advanced end-to-end features of Excel.</p>
                                <p class="mb-3"><strong class="fs-medium">Learning Objective:</strong> After completing this module, you should be able to:</p>
                                <div class="row">
            <div class="col-12 mb-3">
                <ul>
                    <li>Gain knowledge about new features</li>
                    <li>Develop powerful graphs and charts</li>
                    <li>Learn the usage of pivot tables and pivot charts</li>                 
                </ul>
            </div>
                </div>
           <div class="row">
            <div class="col-12 mb-3">
            <p class="mb-3"><strong class="fs-medium">Core Topics:</strong>
                <ul>
                    <li>Basic Excel Training</li>
                    <li>Advanced Excel Training</li>
                    <li>Microsoft Excel for Financial Analysis</li>
                    <li>Working with Pivot Tables Presentation</li>
                    <li>Project on VBA - Financial Modeling using VBA</li>
                    
                    
                </ul>
            </div>

        </div>
                                
                                </div>
                            </div>
                        </div>
                    </div><!-- Item Ends -->

                    <div class="accordion-item bg-white shadow mb-3">
                        <!-- Item Start -->
                        <h2 class="accordion-header" id="excelvba-heading">
                            <button class="accordion-button collapsed fs-medium fw-bold" type="button"
                                data-bs-toggle="collapse" data-bs-target="#excelvba" aria-expanded="false"
                                aria-controls="excelvba">
                                VBA Training (3 Courses, 13+ Projects)	
                            </button>
                        </h2>
                        <div id="excelvba" class="accordion-collapse collapse" aria-labelledby="excelvba-heading"
                            data-bs-parent="#curriculum">
                            <div class="accordion-body">
                                <div class="curriculum-inner-section">
                                <p class="mb-3"><strong class="fs-medium">Goal:</strong> This course will take your Excel skills to the next level and master your Visual Basic Programming and its application.</p>
                                <p class="mb-3"><strong class="fs-medium">Learning Objective:</strong> After completing this module, you should be able to:</p>
                                <div class="row">
            <div class="col-12 mb-3">
                <ul>
                    <li>Use VBA and Macros</li>
                    <li>Learn presentation of CRM</li>
                    <li>Learn how to create barcodes using VBA</li>
                    <li>Learn how to create an interface</li>                 
                </ul>
            </div>
                </div>
           <div class="row">
            <div class="col-12 mb-3">
            <p class="mb-3"><strong class="fs-medium">Core Topics:</strong>
                <ul>
                    <li>VBAs and Macros - Beginners to Beyond</li>
                    <li>Creation of Interactive Dashboards using VBA</li>
                    <li>Creation of Attendance Register </li>
                    <li>Creation of Restaurant Billing System</li>
                    <li>Creation of Basic CRM using VBA</li>
                    <li>Business Barcodes using VBA</li>
                    <li>Financial Modeling using VBA</li>
 
                </ul>
                </div>

</div>
           
                                  
                                </div>
                            </div>
                        </div>
                    </div><!-- Item Ends -->

                    <div class="accordion-item bg-white shadow mb-3">
                        <!-- Item Start -->
                        <h2 class="accordion-header" id="design-heading">
                            <button class="accordion-button collapsed fs-medium fw-bold" type="button"
                                data-bs-toggle="collapse" data-bs-target="#design" aria-expanded="false"
                                aria-controls="design">
                                MS Office Training (13 Courses, 1 Project)
                            </button>
                        </h2>
                        <div id="design" class="accordion-collapse collapse" aria-labelledby="design-heading"
                            data-bs-parent="#curriculum">
                            <div class="accordion-body">
                                <div class="curriculum-inner-section">
                                <p class="mb-3"><strong class="fs-medium">Goal:</strong>This course aims to walk you through several MS Office applications.</p>
                                <p class="mb-3"><strong class="fs-medium">Learning Objective:</strong> After completing this module, you should be able to:</p>
                                <div class="row">
            <div class="col-12 mb-3">
                <ul>
                    <li>Learn MS Excel from scratch</li>
                    <li>Gain conceptual clarity on MS PowerPoint</li>
                    <li>Understand various features and concepts relating to MS Access </li>            
                </ul>
            </div>
                </div>
           <div class="row">
            <div class="col-12 mb-3">
            <p class="mb-3"><strong class="fs-medium">Core Topics:</strong>
                <ul>
                    <li>Microsoft Word</li>
                    <li>Microsoft Excel</li>
                    <li>Microsoft PowerPoint</li>
                    <li>Microsoft Access</li>
                    <li>Microsoft Outlook</li>
                    <li>Microsoft OneNote</li>
                    <li>Microsoft Sway</li>
                    <li>Microsoft Visio</li>
                 </ul>
                </div>
</div>
                                  
                                </div>
                            </div>
                        </div>
                    </div><!-- Item Ends -->

                    <div class="accordion-item bg-white shadow mb-3">
                        <!-- Item Start -->
                        <h2 class="accordion-header" id="project-heading">
                            <button class="accordion-button collapsed fs-medium fw-bold" type="button"
                                data-bs-toggle="collapse" data-bs-target="#project" aria-expanded="false"
                                aria-controls="project">
                                Excel for HR Training (8 Courses, 10+ Projects)
                            </button>
                        </h2>
                        <div id="project" class="accordion-collapse collapse" aria-labelledby="project-heading"
                            data-bs-parent="#curriculum">
                            <div class="accordion-body">
                                <div class="curriculum-inner-section">
                                <p class="mb-3"><strong class="fs-medium">Goal:</strong>This course will walk you through essential excel functions and tools that HR professionals use daily.</p>
                                <p class="mb-3"><strong class="fs-medium">Learning Objective:</strong> After completing this module, you should be able to:</p>
                                <div class="row">
            <div class="col-12 mb-3">
                <ul>
                    <li>Perform rating of employees using features of Excel</li>
                    <li>Create an advanced HR dashboard</li>
                    <li>Create dashboards using VBA</li>            
                </ul>
            </div>
                </div>
           <div class="row">
            <div class="col-12 mb-3">
            <p class="mb-3"><strong class="fs-medium">Core Topics:</strong>
                <ul>
                    <li>Basic Excel Training </li>
                    <li>Advanced Excel Training</li>
                    <li>HR Dashboard using Excel</li>
                    <li>Attendance Register using Microsoft Excel VBA</li>
                    <li>Microsoft Excel for Business Professionals and Managers</li>
                 </ul>
                </div>
</div>
                                   
                                </div>
                            </div>
                        </div>
                    </div><!-- Item Ends -->

                    <div class="accordion-item bg-white shadow mb-3">
                        <!-- Item Start -->
                        <h2 class="accordion-header" id="marketing-heading">
                            <button class="accordion-button collapsed fs-medium fw-bold" type="button"
                                data-bs-toggle="collapse" data-bs-target="#marketing" aria-expanded="false"
                                aria-controls="marketing">
                                Excel for Marketing Training (8 Courses, 13+ Projects)
                            </button>
                        </h2>
                        <div id="marketing" class="accordion-collapse collapse" aria-labelledby="marketing-heading"
                            data-bs-parent="#curriculum">
                            <div class="accordion-body">
                                <div class="curriculum-inner-section">
                                <p class="mb-3"><strong class="fs-medium">Goal:</strong>This course aims to show the applicability of excel concepts and tools from the perspective of marketing managers and professionals.</p>
                                <p class="mb-3"><strong class="fs-medium">Learning Objective:</strong> After completing this module, you should be able to:</p>
                                <div class="row">
            <div class="col-12 mb-3">
                 <ul>
                    <li>Enhance your knowledge of Excel basic and advanced</li>
                    <li>Perform Marketing projects using Excel</li>
                    <li>Do analysis using Excel</li>            
                    <li>Create Marketing dashboards</li>            
                </ul>
            </div>
                </div>
           <div class="row">
            <div class="col-12 mb-3">
            <p class="mb-3"><strong class="fs-medium">Core Topics:</strong>
                <ul>
                    <li>Basic Excel Training </li>
                    <li>Advanced Excel Training</li>
                    <li>Sales Productivity Dashboard</li>
                    <li>Creation of Basic CRM by using Microsoft Excel VBA </li>
                    <li>Performance Ratings of Employees</li>
                    <li>Microsoft Excel Charts and SmartArt Graphics</li>

                 </ul>
                </div>
</div>
                                
                                </div>
                            </div>
                        </div>
                    </div><!-- Item Ends -->

 


                </div><!-- Main Accordian Ends -->
            </div>
        </div>
</section>
<section id="whatyoulearn" class="py-5 site-gradient-2 inner-shadow text-white">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-12 mb-3">
                <h3 class="fs-large-xx mb-3 fw-bold">DOWNLOADABLE EXCEL TEMPLATES (200+)</h3>
               
            </div>
          












            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                      
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">  Formulas </h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                        
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">Formatting</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                       
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">Conditional Formatting</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                      
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">IF, COUNTIF, SUMIF</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                 
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">Graphs and Charts</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                        
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">Data Analysis</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                    
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">What if Analysis</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
  
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">Pivot Tables</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
               
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">Excel Simulations</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                     
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">Sales Dashboard</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                       
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">Power Excel</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 mb-3 p-2 d-flex align-items-center justify-content-center">
                <div class="card shadow p-2 w-100">
                    <div class="d-flex align-items-center justify-content-center">
                       
                        <h4 class="fs-medium ms-3 gradient-text fw-bold m-0">My First Macro</h4>
                    </div>
                </div>
            </div>
            
        </div>
        


    </div>
</section>
<section id="project" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h3 class="text-center fs-large-xx gradient-text mb-3 fw-bold">Projects</h3>
            </div>
            <div class="col-6 col-md-3 mb-3 p-2 d-flex align-items-stretch text-center p-2">
                <div class="card shadow rounded-4 py-3 px-2">
                    <img src="https://www.educba.com/academy/1677240038004/wp-content/uploads/2023/04/serial-number.png"
                        class="w-25 mb-3 mx-auto" alt="">
                    <h4 class="fw-bold mb-3 gradient-text">Attendance Register using Microsoft Excel VBA</h4>
                    <p>In this project, you will learn to design a Students' Attendance Register using Excel VBA tools. It covers how to create buttons, clear or reset information, use frame and image tool, display result, and much more.
                    </p>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-3 p-2 d-flex align-items-stretch text-center p-2">
                <div class="card shadow rounded-4 py-3 px-2">
                    <img src="https://www.educba.com/academy/1677240038004/wp-content/uploads/2023/04/business.png"
                        class="w-25 mb-3 mx-auto" alt="">
                    <h4 class="fw-bold mb-3 gradient-text">Business Barcodes using VBA</h4>
                    <p>In this project, you will learn about the different types of bar codes, how to use a barcode scanner, how to install a barcode ActiveX control, how to generate Barcodes Using Ms-Excel Add-In, and much more.
                    </p>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-3 p-2 d-flex align-items-stretch text-center p-2">
                <div class="card shadow rounded-4 py-3 px-2">
                    <img src="https://www.educba.com/academy/1677240038004/wp-content/uploads/2023/04/dashboard.png"
                        class="w-25 mb-3 mx-auto" alt="">
                    <h4 class="fw-bold mb-3 gradient-text">Advanced HR Dashboard</h4>
                    <p>Excel dashboards aid in the management of large amounts of data as well as the conversion of dashboard data into user-friendly visualizations. These self-paced online tutorials teach you how to design effective and interactive Human Resource (HR) dashboards to produce powerful data visualizations. 
                    </p>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-3 p-2 d-flex align-items-stretch text-center p-2">
                <div class="card shadow rounded-4 py-3 px-2">
                    <img src="https://www.educba.com/academy/1677240038004/wp-content/uploads/2023/04/dashboard-1.png"
                        class="w-25 mb-3 mx-auto" alt="">
                    <h4 class="fw-bold mb-3 gradient-text">Sales Productivity Dashboard</h4>
                    <p>Through this project, we shall understand Database creation, Cluster analysis, Data consolidation, Correlation analysis, Performance linked growth in CTC relative to the target, and much more.  
                    </p>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-3 p-2 d-flex align-items-stretch text-center p-2">
                <div class="card shadow rounded-4 py-3 px-2">
                    <img src="https://www.educba.com/academy/1677240038004/wp-content/uploads/2023/04/desert.png"
                        class="w-25 mb-3 mx-auto" alt="">
                        <h4 class="fw-bold mb-3 gradient-text">Building Dynamic Heat Map in Microsoft Excel </h4>
                    <p>A heat map (or heatmap) is a form of data visualization using a map or diagram with data values displayed as colors. This project will teach you how to utilize a Heat Map to improve your visualization.  
                    </p>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-3 p-2 d-flex align-items-stretch text-center p-2">
                <div class="card shadow rounded-4 py-3 px-2">
                    <img src="https://www.educba.com/academy/wp-content/uploads/2023/03/assessment-1.png"
                        class="w-25 mb-3 mx-auto" alt="">
                    <h4 class="fw-bold mb-3 gradient-text">Project Management Tool with TreeView and ListView using VBA</h4>
                    <p>In this project, you will understand how to implement the CRM application without requiring any code or intensive programming. We'll use Treeview and Listview to build a project management tool. </p>
                </div>
            </div>
           
        </div>
    </div>
</section>

<section id="skillset" class="py-5 site-gradient-2">
    <div class="container">
        <div class="row text-white">
            <div class="col-12">
                <h3 class="fs-large-xx text-center fw-bold mb-5">Skills you will master</h3>
            </div>
            <div class="col-12 col-md-6 mb-5">
                <div class="d-flex align-items-center">
                    <img src="https://www.educba.com/academy/wp-content/uploads/2023/03/accounting.png" class="w-15"
                        alt="">
                        <div>
                    <p class="px-2 fs-large text-center fw-bold">Excel Formulas & Functions</p>     
                    <ul>
                    <li>Building and using advanced formulas like SUMPRODUCT, INDEX, MATCH, and OFFSET</li>
                    <li>Hands-on with Lookup functions</li>
                    <li>Understanding what a PIVOT TABLE is and how to build it</li>                   
                        </ul>
                
                </div>
                </div>
            </div>
            <div class="col-12 col-md-6 mb-5">
                <div class="d-flex align-items-center">
                    <img src="https://www.educba.com/academy/wp-content/uploads/2023/03/xls.png" class="w-15" alt="">
                    <div>
                    <p class="px-2 fs-large text-center fw-bold">	Excel Dashboard</p>     
                    <ul>
                    <li>Building customized dashboards via data visualization techniquesT</li>
                    <li>Understanding excels dashboards basics and utilizing data, charts, graphs, etc.</li>
                    <li>Learning how to track and analyze learning metrics</li>                   
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 mb-5">
                <div class="d-flex align-items-center">
                    <img src="https://www.educba.com/academy/wp-content/uploads/2023/03/technical-support-1.png"
                        class="w-15" alt="">
                        <div>
                    <p class="px-2 fs-large text-center fw-bold">VBA & Macros</p>     
                    <ul>
                    <li>Creating custom user-generated functionsT</li>
                    <li>Hands-on with Lookup functions</li>
                    <li>Learning how to structure the VBA code </li>                   
                        </ul>
                
                </div>
                </div>
            </div>
            <div class="col-12 col-md-6 mb-5">
                <div class="d-flex align-items-center">
                    <img src="https://www.educba.com/academy/wp-content/uploads/2023/03/communication.png" class="w-15"
                        alt="">
                        <div>
                    <p class="px-2 fs-large text-center fw-bold">Excel for Data Analyst</p>     
                    <ul>
                    <li>Learning data aggregation, calculating margins and common ratios</li>
                    <li>Understanding Pivot Tables, Index Match functions, charts, and forecasting trend tools</li>
                    <li>Building charts for organizing data to make it easy and extract insights</li>                   
                        </ul>
                
                </div>
                </div>
            </div>
            <div class="col-12 col-md-6 mb-5">
                <div class="d-flex align-items-center">
                    <img src="https://www.educba.com/academy/1677240038004/wp-content/uploads/2023/04/analyst.png" class="w-15"
                        alt="">
                        <div>
                    <p class="px-2 fs-large text-center fw-bold">Excel for Financial Analyst</p>     
                    <ul>
                    <li>Creating spreadsheets effectively and navigating through them</li>
                    <li>Able to track, update, forecast, and provide periodic reports</li>
                    <li>Understanding popular functions, Valuation equations, and many others</li>                   
                    <li>Managing data reports using pivot tables and filtering options</li>                   
                        </ul>
                
                </div>
                </div>
            </div>
            <div class="col-12 col-md-6 mb-5">
                <div class="d-flex align-items-center">
                    <img src="https://www.educba.com/academy/wp-content/uploads/2023/03/interpersonal-intelligence.png"
                        class="w-15" alt="">
                        <div>
                    <p class="px-2 fs-large text-center fw-bold">Excel for HR</p>     
                    <ul>
                    <li>Learn the tips and tricks to save the number of hours in resolving the difficulties while doing employee compensation, salary, leave, etc.</li>
                    <li>Understanding the formatting techniques for converting data from different sources</li>
                    <li>Getting familiar with essential formulas, making charts, diagrams, and logical functions, and linking the spreadsheets with applications</li> 
                    <li>Learning to automate data by applying advanced techniques to complex data sets.
</li>                   
                        </ul>
                
                </div>
                </div>
            </div>
            <div class="col-12 col-md-6 mb-5">
                <div class="d-flex align-items-center">
                    <img src="https://www.educba.com/academy/wp-content/uploads/2023/03/desing.png" class="w-15" alt="">
                    <div>
                    <p class="px-2 fs-large text-center fw-bold">Excel for Marketing</p>     
                    <ul>
                    <li>Learning PivotTables, conditional formatting, and VBA for large data sets to get examined</li>
                    <li>Able to track monthly statistics, measure the campaigns, and analyze SEO</li>
                    <li>Learning to import, clean, and organize data with tables, sorting and filtering</li>                   
                    <li>Getting acquainted with merging the data with functions like VLOOKUP and XLOOKUP</li>                   
                        </ul>
                
                </div>
                </div>
            </div>
            <div class="col-12 col-md-6 mb-5">
                <div class="d-flex align-items-center">
                    <img src="https://www.educba.com/academy/1677240038004/wp-content/uploads/2023/04/office.png"
                        class="w-15" alt="">
                        <div>
                    <p class="px-2 fs-large text-center fw-bold">Microsoft Office  </p>     
                    <ul>
                    <li>Understanding how to use Word, Excel, and PowerPoint </li>
                    <li>Building spreadsheets to perform calculations, conduct analyses, and explore scenarios</li>
                    <li>Learn to design and construct a database to store, extract, and analyze data</li>                   
                    <li>Creating graphical presentations and charts to share data</li>                   
                        </ul>
                
                </div>
                </div>
            </div>
                </div>

            </div>
        </div>
    </div>
</section>

<section id="benefits" class="py-5">
    <div class="container">
        <div class="row text-center">
            <div class="col-12 mb-3">
                <h3 class="fs-large-xx fw-bold mb-3 gradient-text">Benefits</h3>
                <p class="mb-3">There are several benefits to taking these courses, including</p>
            </div>
        </div>
        <div class="row text-center">
            <div class="col-6 col-md-3 p-2 mb-3 d-flex align-items-strech">
                <div class="card p-2 shadow rounded-3">
                    <img src="https://www.educba.com/academy/wp-content/uploads/2023/03/knowledge.png"
                        class="w-25 mx-auto mb-4 mt-2" alt="">
                    <h4 class="fs-medium mb-3">Gaining knowledge in various fields</h4>
                    <p>Our All-in-One bundles cover a wide range of topics, allowing you to gain understanding in
                        multiple areas. It is beneficial for those professionals looking to change careers.</p>
                </div>
            </div>
            <div class="col-6 col-md-3 p-2 mb-3 d-flex align-items-strech">
                <div class="card p-2 shadow rounded-3">
                    <img src="https://www.educba.com/academy/wp-content/uploads/2023/03/carrer.png"
                        class="w-25 mx-auto mb-4 mt-2" alt="">
                    <h4 class="fs-medium mb-3">Improving career prospects</h4>
                    <p>By gaining knowledge in multiple areas, you can make yourself more attractive to potential
                        employers, leading to better job opportunities and higher salaries.</p>
                </div>
            </div>
            <div class="col-6 col-md-3 p-2 mb-3 d-flex align-items-strech">
                <div class="card p-2 shadow rounded-3">
                    <img src="https://www.educba.com/academy/wp-content/uploads/2023/03/time-money.png"
                        class="w-25 mx-auto mb-4 mt-2" alt="">
                    <h4 class="fs-medium mb-3">Saving time and money</h4>
                    <p>Instead of enrolling in multiple programs, our All in One bundles offer a cost-effective solution
                        by providing access to all the courses in one place.</p>
                </div>
            </div>
            <div class="col-6 col-md-3 p-2 mb-3 d-flex align-items-strech">
                <div class="card p-2 shadow rounded-3">
                    <img src="https://www.educba.com/academy/wp-content/uploads/2023/03/convenience.png"
                        class="w-25 mx-auto mb-4 mt-2" alt="">
                    <h4 class="fs-medium mb-3">Convenience</h4>
                    <p>Access to all the courses in one place makes it easy to manage your learning and take classes at
                        your own pace and on your own schedule.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="features" class="site-gradient-2 text-white py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <img src="https://www.educba.com/academy/wp-content/uploads/2023/03/features-1.png" class="w-100 p-5"
                    alt="">
            </div>
            <div class="col-md-6">
                <h3 class="fs-large-xx fw-bold mb-3">Course Features</h3>
                <p class="mb-3">Here are some of the course features in the All in One bundles</p>
                <div class="features-points">
                    <p class="mb-2"><strong>1. Lifetime access</strong> The bundles offer lifetime access, which means
                        you can access the course content anytime, even after completing the course.</p>
                    <p class="mb-2"><strong>2. Certification</strong> We offer completion certification, which you can
                        add to your resume or LinkedIn profile to showcase your skills to potential employers.</p>
                    <p class="mb-2"><strong>3. Expert support</strong> With expert support, you can email your queries
                        and receive help from industry experts or course instructors.</p>
                    <p class="mb-2"><strong>4. Mobile accessibility</strong> The courses are easily accessible on mobile
                        devices, which allows you to learn on the go and at your own pace.</p>
                    <p class="mb-2"><strong>5. Interactive learning materials</strong> Interactive learning materials
                        such as videos, quizzes, and assignments can help reinforce learned knowledge and improve
                        understanding of the subject.</p>
                    <p class="mb-2"><strong>6. Progress tracking</strong> The bundles offering progress tracking allow
                        learners to track their progress and ensure they meet their learning goals.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="opportunities" class="bg-light inner-shadow py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h3 class="fs-large-xx fw-bold gradient-text mb-3">Career Opportunities</h3>
                <p class="mb-3">Excel is advantageous to employees, employers, and students in many ways. Microsoft Excel boosts students' data management skills. If you know Excel, it increases your chances of getting hired by a reputed company. Employees and employers can benefit from Excel knowledge. Excel is a critical skill that will help you climb up the ladder in your career. </p>
                <div class="opportunities-points">
                    <p class="mb-2"><strong>a.	Data Analyst</strong></p>
                    <p class="mb-2"><strong>b.	Financial Analyst</strong></p>
                    <p class="mb-2"><strong>c.	Investment Banking Analyst</strong></p>
                    <p class="mb-2"><strong>d.	Equity Research Analyst</strong></p>
                    <p class="mb-2"><strong>e.	Credit Analyst</strong></p>
                    <p class="mb-2"><strong>f.	Risk Analyst</strong></p>
                    <p class="mb-2"><strong>g.	Private Equity Analyst</strong></p>
                    <p class="mb-2"><strong>h.	Accountant</strong></p>
                    <p class="mb-2"><strong>i.	Auditor</strong></p>
                    <p class="mb-2"><strong>j.	Business Analyst</strong></p>
                    <p class="mb-2"><strong>k.	Financial Analyst</strong></p>
                    <p class="mb-2"><strong>l.	HR Analyst</strong></p>
                    
                    <p class="mb-2"><strong class="fs-large">Our alumni in top companies</strong>
                    </p>
                    <p class="mb-2"><strong>1.	Deloitte</strong></p>
                    <p class="mb-2"><strong>2.	Accenture</strong></p>
                    <p class="mb-2"><strong>3.	KPMG</strong></p>
                    <p class="mb-2"><strong>4.	Boston Consulting Group</strong></p>
                    <p class="mb-2"><strong>5.	HDFC</strong></p>
                    <p class="mb-2"><strong>6.	ICICI</strong></p>
                    <p class="mb-2"><strong>7.	Goldman Sachs</strong></p>
                    <p class="mb-2"><strong>8.	JPMorgan Chase</strong></p>
                    <p class="mb-2"><strong>9.	Citigroup</strong></p>
                    <p class="mb-2"><strong>10.	Bank of America</strong></p>
                    <p class="mb-2"><strong>11.	Credit Suisse</strong></p>
                    <p class="mb-2"><strong>12.	Deutsche Bank</strong></p>
                    <p class="mb-2"><strong>13.	Morgan Stanley</strong></p>
                    <p class="mb-2"><strong>14.	Bain & Company</strong></p>
                    <p class="mb-2"><strong>15.	McKinsey & Co.</strong></p>
                    <p class="mb-2"><strong>16.	Barclays</strong></p>
                    <p class="mb-2"><strong>17.	SBI</strong> </p>
                   
                </div>

            </div>
            <div class="col-md-6 d-flex align-items-center">
                <img src="https://www.educba.com/academy/1677240038004/wp-content/uploads/2023/04/chart.png" class="w-100"
                    alt="chart">
            </div>
        </div>
    </div>
</section>

<section id="whotakecourse" class="py-5 site-gradient-2">
    <div class="container">
        <div class="row">
            <div class="col-md-12 mb-3">
                <h3 class="text-white text-center fs-large-xx fw-bold">Who is the Target Audience for this Excel VBA Course?</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-6 col-md-3 mb-3 d-flex align-items-strech">
                <div class="card text-center shadow rounded-5">
                    <img src="https://www.educba.com/academy/wp-content/uploads/2023/03/student.png"
                        class="card-img-top rounded-5 mb-3" alt="">
                    <h4 class="fs-medium fw-bold gradient-text mb-3">Students</h4>
                    <p class="mb-3 px-2">Students from the finance, HR, or marketing domain can do this Excel VBA course. They will not only learn the nitty-gritty of Excel in their domain but can also try their hands on other courses.</p>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-3 d-flex align-items-strech">
                <div class="card text-center shadow rounded-5">
                    <img src="https://www.educba.com/academy/wp-content/uploads/2023/03/working-professional.png"
                        class="card-img-top rounded-5 mb-3" alt="">
                    <h4 class="fs-medium fw-bold gradient-text mb-3">Working professionals</h4>
                    <p class="mb-3 px-2">Professionals from the HR, Marketing, or Finance domain can take this comprehensive course. They will also be able to master their domain (excel) and get great insights from the additional courses.</p>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-3 d-flex align-items-strech">
                <div class="card text-center shadow rounded-5">
                    <img src="https://www.educba.com/academy/wp-content/uploads/2023/03/entrepreneurs.png"
                        class="card-img-top rounded-5 mb-3" alt="">
                    <h4 class="fs-medium fw-bold gradient-text mb-3">Entrepreneurs</h4>
                    <p class="mb-3 px-2">As entrepreneurs, you need to be the jack of all trades. This Excel VBA training will help you learn many valuable micro-skills that may help you in your entrepreneurial journey. </p>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-3 d-flex align-items-strech">
                <div class="card text-center shadow rounded-5">
                    <img src="https://www.educba.com/academy/wp-content/uploads/2023/03/career-changers.png"
                        class="card-img-top rounded-5 mb-3" alt="">
                    <h4 class="fs-medium fw-bold gradient-text mb-3">Analysts</h4>
                    <p class="mb-3 px-2">This course is for you if you are an analyst who works as Financial Analyst or Data Scientist. Whether you are in entry-level or experienced professional, this course will teach you various techniques.</p>
                </div>
            </div>
        </div>
    </div>

</section>


<section id="pre-requisite" class="py-5">
    <div class="container">
        <div class="row p-5 my-5 shadow-lg rounded-5">
            <div class="col-12">
                <div class="row">
                    <div class="col-12">
                        <h3 class="fs-large-xx fw-bold gradient-text text-center mb-3">Pre-Requisites</h3>
                        <div class="row">
                            <div class="col-md-8 d-flex align-items-center">
                                <div class="me-3 text-justify">
                                    <p><strong>Willingness to learn:</strong> You must have the zest for learning this All in One Excel VBA Course if you want to raise the bar in your career and develop new opportunities in the market. </p>
                                    <p><strong>Basic individual domain knowledge:</strong> Not all courses need any prior knowledge. But for domain-specific courses, you need basic domain knowledge, so you don’t get stuck while learning the material.</p>
                                </div>
                            </div>
                            <div class="col-md-4 p-2">
                                <img src="https://temprestr.educba.com/academy/wp-content/uploads/2023/03/prerequisite.png"
                                    class="bg-white p-1 rounded-5 shadow">
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="faq" class="site-gradient-2 py-5">
    <div class="container">
        <div class="row mt-5 p-5 shadow-lg rounded-5 bg-white">
            <div class="col-12">
                <h3 class="fs-large-xx mt-3 fw-bold text-dark-background mb-3 text-center gradient-text">FAQ</h3>
                <p class="fw-bold fs-medium">Here are frequently asked questions (FAQ) that someone might have about the All-in-One bundles:</p>
                <br><p class="fw-bold">Why should you join this Excel VBA Course?</p>
                <p class="mb-3">The All in one Excel VBA Course from EDUCBA will give you a thorough understanding of MS Excel. The course is helpful for all profiles, from junior-level employees to top-level managerial positions.</p>

                <p class="mb-3">We will talk about Excel skills that are categorized under 3  levels.</p>
                <ol>
                    <li>Basic Excel</li>
                    <li>Intermediate level</li>
                    <li>Advanced Excel</li>
                </ol>
                <p class="mb-3"> <strong>1.	Basic Excel:-</strong>  
It covers basic features of excel and how to perform the essential tasks, which include cell referencing, table borders, sorting, filtering, graphs, creating and formatting worksheets, entering, editing data, creating basic formulas, working with functions, and much more.
                </p>
                <p class="mb-3">
<strong>2.	Intermediate Excel:-</strong> 
It will help to organize data into comprehensive sheets, which efficiently represent data with charts and graphs.It will also make it easier to understand functions and formulas like SUMPRODUCT, AVERAGE, SUM, and much more.</p>

<p class="mb-3">
<strong>3. Advanced Excel:-</strong> 
Here you will gain knowledge of complex topics like VBA programming, data simulation, analytics, and advanced formula usage. Also, building and applying INDIRECT, INDEX MATCH, OFFSET  formulas, Reading, editing, or modifying simple recorded macros are part of this course.
<br>
You will also learn hands-on projects such as building HR Dashbaorad, sales productivity dashboard, heat maps, attendance registrar, business barcodes with VBA, etc.
</p>

                <br><p class="fw-bold">How will this course help you to win job offers?</p>
                <p class="mb-3">
                Excel is one of the most demanded skills in today's growing market. It opens many job opportunities for individuals who are experts in this skill.</p>
                <p class="mb-3">
We have listed a few jobs that make use of Excel to give you a head start in your career:</p>
<p class="mb-3"><strong>
1.	Financial Professionals:-</strong>
Finance professionals should have MS Excel knowledge inside out. It will help you evolve competitively for any finance job and crack all the assignments with confidence. Knowledge about spreadsheets, pivot tables, filtering, and popular functions VLOOKUP and SUMIFS will help you to become competent. Moreover, it will help you to make investment decisions.
</p><p class="mb-3"><strong>
2.	Administrative Assistant:-</strong>
Excel is also useful for administrative tasks, including tasks such as bookkeeping, generating reports, invoicing, contacting suppliers, paying bills, and many more. Advanced Excel Skills helps individuals working in administrative jobs to help them make themselves marketable and gain an edge over the competition.
</p><p class="mb-3"><strong>
3.	Business Analyst:-</strong>
Business Analysts are primarily responsible for defining strategy, creating the enterprise architecture, defining goals, and improving business processes. Advance excel functions such as Macros, conditional formatting, histogram, data validation, and analysis can help fetch important information to make better decisions.

                </p>

                <br><p class="fw-bold">What tangible skills will you learn from this course?</p>
                <p class="mb-3">The truth is you will learn many, many micro-skills in this Excel VBA Certification course. We’re highlighting the most significant ones –</p>
                <ul>
<li><strong> VBA & Macros:</strong> If you’ve never done VBA & Macros, this Excel VBA course will teach you the fundamentals and more. You will not only learn theoretical aspects but will also master practical elements.</li>
<li><strong>
MS Excel (Basic & Advanced):</strong> After this Excel VBA training, you will master MS Excel. No other course or material is required.</li>
<li><strong>
MS Excel (domain-specific):</strong> You will also learn MS Excel for HR, Marketing, and Finance separately to focus more on one domain and browse the other courses for exciting parts.</li>
<li><strong>
MS Office:</strong> You will also master MS Office in its entirety. And we make things easy for you. Buy one comprehensive course and forget about building these micro-skills.</li>
</ul>
</p>
                <p class="fw-bold">How do a novice get started with Microsoft Excel?
                </p>
                <p class="mb-3">Novices who wish to learn MS Excel should begin with the fundamentals. After you've mastered the fundamentals of MS Excel, you may go to more complex topics.</p>
                <p class="fw-bold">What are the other Excel Courses offered by EDUCBA?
                </p>
                <p class="mb-3">
                The other courses offered by EDUCBA are listed below:-
                <ul>
                    <li><a href="https://www.educba.com/excel/courses/excel-course/">Excel Training (23 Courses,9+ Projects)</a></li>
                    <li><a href="https://www.educba.com/excel/courses/excel-advanced-course/">Excel Advanced Training (16 Courses, 23+ Projects)</a></li>
                    <li><a href="https://www.educba.com/excel/courses/vba-course/">VBA Training (3 Courses, 13+ Projects)</a></li>
                    <li><a href="https://www.educba.com/excel/courses/excel-data-analysis-course/">Excel Data Analysis Training (17 Courses, 8+ Projects)</a></li>
                    <li><a href="https://www.educba.com/excel/courses/excel-for-hr-training/">Excel For HR Training (8 Courses, 10+ Projects)</a></li>
                </ul>
                </p>
                <p class="fw-bold">Is there any validity for this All in Once Excel VBA Course?
                </p>
                <p class="mb-3"> Once you've registered for the course, you can access it whenever possible. You will always have access to the video recordings and reference materials.</p>
                <p class="fw-bold">Can I download the course's reference materials?
                </p>
                <p class="mb-3">Absolutely! You can download every excel file required for a course. Look for a module in the course dashboard that lists downloadable reference files.</p>
                <p class="fw-bold">What about group discounts or Corporate Training?
                </p>
                <p class="mb-3">Yes, EDUCBA offers corporate trainings and group discounts. Send an email with your inquiry to info@educba.com for more information. We provide discounts in accordance with the terms and conditions depending on the group size.</p>

                <p class="fw-bold">Why should I do this Excel VBA Certification?
                </p>
                <p class="mb-3">EDUCBA Excel VBA Certification is the most robust and comprehensive course available. It will help you become a Microsoft Excel expert and will help you to get a career in the field as its advanced course.</p>
                <p class="fw-bold">I’m yet to start my professional life, can I do this Excel VBA Certification Course?
                </p>
                <p class="mb-3">Why not? It will add immense value to your professional growth if you take this course. It will keep you ahead of your peers.</p>
                <p class="fw-bold">Why do you think this is the best Excel VBA training in the market?
                </p>
                <p class="mb-3">It is a comprehensive, detailed course with engaging video tutorials and reference materials to train you on the Excel VBA aspects. It will help you raise your market productivity level, immensely building your career prospects.</p>
            </div>
        </div>
    </div>
</section><!-- Faq Closed -->
<section id="certificate" class="bg-light py-5 inner-shadow text-center">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <h3 class="fs-large-xx fw-bold mb-5 text-dark-background">Certificate of
                            Completion
                        </h3>
                    </div>
                    <div class="col-md-12">
                        <img width="962" height="722" src="https://cdn.educba.com/academy/wp-content/uploads/2022/07/Excel-VBA-Certification-Course-Certification.jpg.webp" alt="" class="img-responsive w-100 shadow-lg rounded-1 lazyloaded" data-ll-status="loaded"><noscript><img width="962" height="722" src="https://cdn.educba.com/academy/wp-content/uploads/2022/07/Excel-VBA-Certification-Course-Certification.jpg.webp" alt="" class="img-responsive w-100 shadow-lg rounded-1"></noscript>
                    </div>
                </div>
                <div class="col-12"><br>
                <p class="fw-bold fs-large">Build your skills to get Job Ready.</p>
                <p class="mb-3 text-left">Learning new skills will help you in your professional career to achieve your goals, boost confidence, and motivate you to embark on it. Here is where EDUCBA Excel VBA Course comes to help you enhance your knowledge to improve and build your portfolio for your desired job role.</p>
                <div class="col-12"><br>
                <p class="fw-bold fs-large">Earn & Share your accomplishment.</p>
                <p class="mb-3 text-left">To assist you in starting your career, you can share the certificate with your professional network on Linkedin once you complete the course.</p>

            </div>
            <!-- Container closed -->
        </section>

<section id="testimonial-2" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-4 d-flex align-items-stretch">
                <div class="card rounded-3 testimonial-new site-gradient-2 p-4 text-white">
                    <div class="d-flex py-5">
                        <div class="person-details ms-2">
							<h5 class="fs-medium m-0">Patrick Naah</h5>
                        </div>
                    </div>                    
                    <div class="testimonial-text mt-5">
                    I just didn’t give the full 5 stars because the course is too short. It’s so well explained that we want to learn more. I one is looking for an introduction to VBA, this is the perfect Excel VBA Certification course. And I would recommend people to join this course shortly. But this Excel VBA course should be longer, to introduce more concepts
					</div>
                </div>
            </div>            
            <div class="col-md-4 mb-4 d-flex align-items-stretch">
                <div class="card rounded-3 testimonial-new site-gradient-2 p-4 text-white">
                    <div class="d-flex py-5">                        
                        <div class="person-details ms-2">
                           <h5 class="fs-medium  m-0">David Gamboa</h5>
                        </div>
                    </div>                    
                    <div class="testimonial-text mt-5">This Excel VBA Certification course had some decent entry-level VBA examples and would be very friendly for new users. It explains how to record macros and how to edit them afterward. The examples are simple enough that a newcomer should be able to follow along.

I would recommend this Excel VBA training to anyone who wants to get started with Excel Macros.</div>
                </div>
            </div>
			<div class="col-md-4 mb-4 d-flex align-items-stretch">
                <div class="card rounded-3 testimonial-new site-gradient-2 p-4 text-white">
                    <div class="d-flex py-5">
                        <div class="person-details ms-2">
							<h5 class="fs-medium  m-0">Adheres Sharma</h5>
                        </div>
                    </div>                    
                    <div class="testimonial-text mt-5">The Excel VBA Certification course I did on Basic Excel was amazing and the way the videos are designed it becomes so easy to understand the concepts. the course helped me in clearing a lot of my doubts regarding the shortcuts that can be used in excel to simplify the work and maximize productivity. it was an amazing experience and I would like to thank eduCBA for it.</div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 mb-4 d-flex align-items-stretch">
                <div class="card rounded-3 testimonial-new site-gradient-2 p-4 text-white">
                    <div class="d-flex py-5">
                        <div class="person-details ms-2">
							<h5 class="fs-medium m-0">Jose Martinez</h5>
                        </div>
                    </div>                    
                    <div class="testimonial-text mt-5">
                    Easy to follow content. Very basic and well explained. The course has the worksheets available for download so the student can review the content after each lecture. If you are an avid Excel user this Excel VBA Certification course will be very boring. This Excel VBA training is perfect for someone who knows nothing about Excel or someone who knows a little. The keyboard shortcuts are a tool everyone should learn.
					</div>
                </div>
            </div>            
            <div class="col-md-4 mb-4 d-flex align-items-stretch">
                <div class="card rounded-3 testimonial-new site-gradient-2 p-4 text-white">
                    <div class="d-flex py-5">                        
                        <div class="person-details ms-2">
                           <h5 class="fs-medium  m-0">Lee Ta</h5>
                        </div>
                    </div>                    
                    <div class="testimonial-text mt-5">Very good basic Excel training course. The course covers many basic fundamental and key features and enables the beginner to learn and practice and be ready to use what has been learned in this course to apply to real-life projects. This Excel VBA Certification course is a good beginner course and prepare beginner well for advance courses.</div>
                </div>
            </div>
			<div class="col-md-4 mb-4 d-flex align-items-stretch">
                <div class="card rounded-3 testimonial-new site-gradient-2 p-4 text-white">
                    <div class="d-flex py-5">
                        <div class="person-details ms-2">
							<h5 class="fs-medium  m-0">Michael Akpawu</h5>
                        </div>
                    </div>                    
                    <div class="testimonial-text mt-5">The most comprehensive online course on Excel VBA. I have been exposed to advanced functions in excel and I am extremely happy my proficiency level in Microsoft Excel is advanced. This has been incredibly helpful to me as a portfolio analyst as I can complete excel related projects efficiently and effectively.</div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 mb-4 d-flex align-items-stretch">
                <div class="card rounded-3 testimonial-new site-gradient-2 p-4 text-white">
                    <div class="d-flex py-5">
                        <div class="person-details ms-2">
							<h5 class="fs-medium m-0">Nikunja Nawal</h5>
                        </div>
                    </div>                    
                    <div class="testimonial-text mt-5">
                    It was a great learning experience and I have mastered Excel after availing this Excel VBA Certification course. The course was detailed and easy to grasp. It was very handy and helped me in many of my projects during my MBA studies. The division of the Excel VBA training and the different versions of Excel being stacked into a single course is amazing and different from other courses.
					</div>
                </div>
            </div>            
            <div class="col-md-4 mb-4 d-flex align-items-stretch">
                <div class="card rounded-3 testimonial-new site-gradient-2 p-4 text-white">
                    <div class="d-flex py-5">                        
                        <div class="person-details ms-2">
                           <h5 class="fs-medium  m-0">Alvaro Chagas da Luz Neto</h5>
                        </div>
                    </div>                    
                    <div class="testimonial-text mt-5">a complete guide for anyone who wants to master excel.

This Excel VBA training was made for people who had never touched an excel spreadsheet, so if you have some knowledge, skip the first modules. Later on, the course teaches in an easy way concepts like pivot tables and Filters. Something I found unique was the shortcut videos and presentation. Even though most people use Excel daily, most of us don’t some basic shortcuts that can spare us a good time and how to adapt it to a printed version.

Recommend this course to anyone</div>
                </div>
            </div>
			<div class="col-md-4 mb-4 d-flex align-items-stretch">
                <div class="card rounded-3 testimonial-new site-gradient-2 p-4 text-white">
                    <div class="d-flex py-5">
                        <div class="person-details ms-2">
							<h5 class="fs-medium  m-0">William Schulz</h5>
                        </div>
                    </div>                    
                    <div class="testimonial-text mt-5">This Excel VBA Certification course was very thorough and well structured. I learned a significant amount about the different functionalities in Excel and feel like I have at least a basic understanding of many if not all of the features in the program. With practice over time I hope to build on the foundation this course has provided me.</div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 mb-4 d-flex align-items-stretch">
                <div class="card rounded-3 testimonial-new site-gradient-2 p-4 text-white">
                    <div class="d-flex py-5">
                        <div class="person-details ms-2">
							<h5 class="fs-medium m-0">Nitesh Tiwari</h5>
                        </div>
                    </div>                    
                    <div class="testimonial-text mt-5">
                    Educa provides a great platform for developing various office skills. I heard about EduCba from a website and explored it. I have enrolled for various courses which are very instructive and user friendly. Excel Advanced course caught my eye when I was looking to learn excel formulas that are not used frequently. It is a well designed Excel VBA Certification course thereby serving all the needs of a professional in an office environment. Thank You for providing such a platform!
					</div>
                </div>
            </div>            
            <div class="col-md-4 mb-4 d-flex align-items-stretch">
                <div class="card rounded-3 testimonial-new site-gradient-2 p-4 text-white">
                    <div class="d-flex py-5">                        
                        <div class="person-details ms-2">
                           <h5 class="fs-medium  m-0">Shi Qing Ng</h5>
                        </div>
                    </div>                    
                    <div class="testimonial-text mt-5">Clear and easy to follow. Good examples used. Good dynamic codes introduced that can be applied to different scenarios. A detailed explanation of the use of Userforms. EduCBA staffs are responsive and provide me with the help/information I need, easing my learning process. Should introduce more VBA functions.</div>
                </div>
            </div>
			<div class="col-md-4 mb-4 d-flex align-items-stretch">
                <div class="card rounded-3 testimonial-new site-gradient-2 p-4 text-white">
                    <div class="d-flex py-5">
                        <div class="person-details ms-2">
							<h5 class="fs-medium  m-0">Thomas J. Young</h5>
                        </div>
                    </div>                    
                    <div class="testimonial-text mt-5">Excellent course for beginners and experienced Excel users. This basic course fills gaps in knowledge. I have reviewed this course for use in training staff. Information is presented with clarity and in a logical pedagogical sequence. Experienced users can easily fast forward to get to the relevant nuggets of information that might be new to them. For the novice/beginner, this Excel VBA Certification course covers the key foundational elements you’ll need to use 80% of the time.</div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 mb-4 d-flex align-items-stretch">
                <div class="card rounded-3 testimonial-new site-gradient-2 p-4 text-white">
                    <div class="d-flex py-5">
                        <div class="person-details ms-2">
							<h5 class="fs-medium m-0">Antonio Tirado</h5>
                        </div>
                    </div>                    
                    <div class="testimonial-text mt-5">
                    This is an excellent Excel VBA training, very useful and interesting. The instructor explains everything thoroughly and the examples that he provides are very good as well. The pace at which the lessons are explained is appropriate. I recommend this course.
					</div>
                </div>
            </div>            
            <div class="col-md-4 mb-4 d-flex align-items-stretch">
                <div class="card rounded-3 testimonial-new site-gradient-2 p-4 text-white">
                    <div class="d-flex py-5">                        
                        <div class="person-details ms-2">
                           <h5 class="fs-medium  m-0">Hima Indhukuri</h5>
                        </div>
                    </div>                    
                    <div class="testimonial-text mt-5">This Excel VBA Certification course will explain the concepts of excel in a very simple and clear way and gives a very detailed understanding of excel software. The practical excel files were attached to this course which came very handy so that I could practice what was being taught using the same data in excels without wasting time looking for data. Also, the curriculum of Excel VBA training is well designed</div>
                </div>
            </div>
			<div class="col-md-4 mb-4 d-flex align-items-stretch">
                <div class="card rounded-3 testimonial-new site-gradient-2 p-4 text-white">
                    <div class="d-flex py-5">
                        <div class="person-details ms-2">
							<h5 class="fs-medium  m-0">Raghuram Vedula</h5>
                        </div>
                    </div>                    
                    <div class="testimonial-text mt-5">The teaching method of the trainer is very good and the overall structure of the course is thoughtfully organized to make participants easily adapt to the complexity. The trainer is very clear and made the complex content easy to understand. The coverage of the topic is also very good wherein the trainer covered almost all the important areas of Excel. Overall, after this session, my efficiency in Excel has increased significantly. Thank you for such a wonderful session.</div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 mb-4 d-flex align-items-stretch">
                <div class="card rounded-3 testimonial-new site-gradient-2 p-4 text-white">
                    <div class="d-flex py-5">
                        <div class="person-details ms-2">
							<h5 class="fs-medium m-0">Rahul Upadhyay</h5>
                        </div>
                    </div>                    
                    <div class="testimonial-text mt-5">
                    In this Excel VBA Certification, we’ve learned how to make User forms and try to code, automate and tweak various attributes. we also learned how to code on VBA and how macros would help us to build code for the same.
for coding, we would take help from the excel and would tweak the code for our use. we also learned how arrays, looping would help us in coding and we also learned how to print and email the PDFs. It was enriching the learning experience.
					</div>
                </div>
            </div>            
            <div class="col-md-4 mb-4 d-flex align-items-stretch">
                <div class="card rounded-3 testimonial-new site-gradient-2 p-4 text-white">
                    <div class="d-flex py-5">                        
                        <div class="person-details ms-2">
                           <h5 class="fs-medium  m-0">Akshay Zaveri</h5>
                        </div>
                    </div>                    
                    <div class="testimonial-text mt-5">This Advanced Excel 2010 course explains the difficult concepts of excel in a very simple and clear way and gives a very detailed understanding of excel software. Excel is the best spreadsheet software available and in my opinion is the most important software for any company. Also, the curriculum of Excel VBA Certification course is well designed</div>
                </div>
            </div>
			<div class="col-md-4 mb-4 d-flex align-items-stretch">
                <div class="card rounded-3 testimonial-new site-gradient-2 p-4 text-white">
                    <div class="d-flex py-5">
                        <div class="person-details ms-2">
							<h5 class="fs-medium  m-0">Navneet Kaur</h5>
                        </div>
                    </div>                    
                    <div class="testimonial-text mt-5">This Excel VBA training is really helpful for those who have a strong passion for learning excel. The way the formulae and features are explained is quite good. Also the pace of teaching is good. The files attached for practice makes it easier for people to apply what they have learned and check whether they have understood the course.</div>
                </div>
            </div>
        </div>
    </div>
</section>

<div id="topdiv" class="bg-dark py-1 w-100">
    <div class="container text-white strip-container">
        <div class="d-flex align-items-center justify-content-center m-0">
            <del>₹ 40000</del>
            <div class="ms-2 fs-large">₹ 29999</div>
            <a href="https://www.educba.com/all-in-one" class="ms-3 btn fs-medium fw-bold site-gradient-2 text-white">Take
                    this Bundle</a>            
        </div>
        <img alt="Limited Period Offer" src="https://cdn.educba.com/images/Limited_Period_Offer.png" style="width:80px;">
    </div>
</div>
<section class="py-5"></section>




<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous">
</script>

<script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>

<script>
// Set the date we're counting down to
var today = new Date();
var tomorrow = new Date();
tomorrow.setDate(today.getDate() + 1);
var countDownDate = tomorrow.setHours(0, 0, 0, 0);

// Update the count down every 1 second
var x = setInterval(function() {


    var now = new Date().getTime();
    var distance = countDownDate - now;
    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);

    /*document.getElementById("timer").innerHTML = days + "d " + hours + "h "
    + minutes + "m " + seconds + "s ";*/

    if (hours < 10) {
        document.getElementById("hour").innerHTML = "0" + hours;
    } else {
        document.getElementById("hour").innerHTML = hours;
    }

    if (minutes < 10) {
        document.getElementById("minute").innerHTML = "0" + minutes;
    } else {
        document.getElementById("minute").innerHTML = minutes;
    }

    if (seconds < 10) {
        document.getElementById("second").innerHTML = "0" + seconds;
    } else {
        document.getElementById("second").innerHTML = seconds;
    }


    /*document.getElementById("minute").innerHTML = minutes;
    document.getElementById("second").innerHTML = seconds;*/

    if (distance < 0) {
        clearInterval(x);
        document.getElementById("demo").innerHTML = "EXPIRED";
    }
}, 1000);

</script>

<script type="text/javascript">
jQuery(window).scroll(function() {
    topdiv = document.getElementById('topdiv');
    if (window.pageYOffset > 1700) {
        topdiv.style.display = "block";
    } else if (window.pageYOffset < 1700) {
        topdiv.style.display = "none";
    }
});
</script>
